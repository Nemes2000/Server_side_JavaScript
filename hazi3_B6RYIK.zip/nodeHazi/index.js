var express = require('express');
var app = express();

/**
 * Include all the routes
 */
require('./routes/routing')(app);

//use the static middleware
app.use(express.static('static'));

/**
 * Standard error handler
*/
app.use(function (err, req, res, next) {
    res.status(500).send('Houston, we have a problem!');
  
    //Flush out the stack to the console
    console.error(err.stack);
  }); 

var server = app.listen(3000, function () {
    console.log("On: 3000"); 
});