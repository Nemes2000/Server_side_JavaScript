/* Adatbázisbol megszerzi az összes étterem összes adatát*/
module.exports = function (objectrepository) {
    return function (req, res, next) {
       return next();
    }
}