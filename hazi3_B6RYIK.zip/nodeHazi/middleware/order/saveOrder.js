//elmenti adatbazisba a rendelest
module.exports = function (objectrepository) {
        return function (req, res, next) {
                return res.redirect('/order');          
        }
}