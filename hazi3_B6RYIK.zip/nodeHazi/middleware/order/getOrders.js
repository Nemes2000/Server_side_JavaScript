//Lekerdezi az osszes rendelest az adatbazisbol
module.exports = function (objectrepository) {
    return function (req, res, next) {
        return next();
    }
}