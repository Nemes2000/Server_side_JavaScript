//parameterek alapjan az adoott rendelest lekerdezi az adatbazisbol
module.exports = function (objectrepository) {
    return function (req, res, next) {
        return next();
    }
}