//torli az adott canteen osszes kinalatat
module.exports = function (objectrepository) {
    return function (req, res, next) {
        return next();
    }
}