//Adott canteen kinalatat szerzi meg az adatbazisbol
module.exports = function (objectrepository) {
    return function (req, res, next) {
        return next();
    }
}