//adott canteen adott kinalatat torli
module.exports = function (objectrepository) {
    return function (req, res, next) {
        return res.redirect('/offer/' + req.params.canteenid);
    }
}