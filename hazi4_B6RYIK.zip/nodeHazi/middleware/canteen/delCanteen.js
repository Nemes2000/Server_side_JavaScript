//törli a paraméterkét kapott canteen-t
//majd átirányit az /canteen oldalra
module.exports = function (objectrepository) {
    return function (req, res, next) {
        return res.redirect('/canteen');
    }
}