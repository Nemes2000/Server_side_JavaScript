//ha paraméterként kapja a canteen id-t akkor lekérdezi azon canteen-t
//ha body-ban van az adat akkor onnan szerzi meg az id-t   
//                  -> több helyröl is hívom a getcanteen-t és nem mindig ugyan onnan tudom megszerezni az adatot
//          ha van id, akkor az alapján lekérdezi az adott canteen-t
module.exports = function (objectrepository) {
    return function (req, res, next) { 
        res.locals.canteen = {
            _id : "2",
            name : "egyes",
            leader : "nev1",
            description : "leiras1.......................................",
            mobil : "0000000"
        };
        return next();
    }
}