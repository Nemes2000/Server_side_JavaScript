//Adott rendelest torol
module.exports = function (objectrepository) {
    return function (req, res, next) {
        return res.redirect('/order');
    }
}