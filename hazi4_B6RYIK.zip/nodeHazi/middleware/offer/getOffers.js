//Adott canteen kinalatat szerzi meg az adatbazisbol
module.exports = function (objectrepository) {
    return function (req, res, next) {
        res.locals.offers = [
            {
                _id : "1",
                name : "egyes",
                price : "1000",
                description : "leiras1"
            },
            {
                _id : "2",
                name : "kettes",
                price : "2000",
                description : "leiras2"
            },
            {
                _id : "3",
                name : "harmas",
                price : "3000",
                description : "leiras3"
            }
        ]
        return next();
    }
}