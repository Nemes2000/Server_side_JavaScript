/* ha a res.body-on volt rejtett adat akkor módositas van
   ha viszont nincsen rajta adat akkor új canteen-t kell létrehozni
        majd elmenti az adatokat*/
module.exports = function (objectrepository) {
    return function (req, res, next) {
        return res.redirect('/offer/'+res.locals.canteen._id);
    }
}