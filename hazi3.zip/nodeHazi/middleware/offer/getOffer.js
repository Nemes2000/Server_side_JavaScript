//adott étterem adott ételét kérdezi le az adatbázisból
module.exports = function (objectrepository) {
    return function (req, res, next) {
        next();
    }
}