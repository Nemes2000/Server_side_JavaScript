//adott étterem adott éetlét törli
module.exports = function (objectrepository) {}