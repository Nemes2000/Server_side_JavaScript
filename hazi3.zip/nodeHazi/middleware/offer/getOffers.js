//Adott étterem menű kinálatát szerzi meg az adatbázisból
module.exports = function (objectrepository) {}