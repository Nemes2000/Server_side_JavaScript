//Adott étterem menű kinálatát szerzi meg az adatbázisból
module.exports = function (objectrepository) {
    return function (req, res, next) {
        next();
    }
}