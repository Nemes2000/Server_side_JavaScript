//paraméterként kapott étterem adatai szerzi meg az adatbázisból
module.exports = function (objectrepository) {
    return function (req, res, next) {
        next();
    }
}