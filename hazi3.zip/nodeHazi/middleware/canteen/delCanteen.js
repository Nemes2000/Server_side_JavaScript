//törli a paraméterkét kapott éttermet
//majd átirányit az /offer/:canteen oldalra
module.exports = function (objectrepository) {
    return function (req, res, next) {
        next();
    }
}