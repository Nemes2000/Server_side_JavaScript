/* A tartalmat jeleniti meg*/
module.exports = function (objectrepository) {}