/* A tartalmat jeleniti meg*/
module.exports = function (objectrepository) {
    return function (req, res, next) {
        next();
    }
}