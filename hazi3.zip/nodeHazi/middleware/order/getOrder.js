//adoott rendelést lekérdezi az adatbázisból
module.exports = function (objectrepository) {}