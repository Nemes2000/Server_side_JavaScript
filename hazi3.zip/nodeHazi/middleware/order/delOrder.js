//Adott rendelést töröl
module.exports = function (objectrepository) {}