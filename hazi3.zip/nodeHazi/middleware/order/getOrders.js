//Lekérdezi az összes rendelést az adatbázisból
module.exports = function (objectrepository) {
    return function (req, res, next) {
        next();
    }
}