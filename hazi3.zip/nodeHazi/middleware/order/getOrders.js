//Lekérdezi az összes rendelést az adatbázisból
module.exports = function (objectrepository) {}